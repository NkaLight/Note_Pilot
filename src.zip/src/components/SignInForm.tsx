"use client";
import { useSession } from "@/context/SessionContext";
import { useRouter } from "next/navigation";
import { useState } from "react";
import LoadingCircles from "@/components/LoadingCircles";
import { useAuthContext } from "@/context/AuthContext";
// Define the type for the props
interface SignInFormProps {
  closeForm: () => void;
}

export default function SignInForm({closeForm}: SignInFormProps){
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const {setUser} = useSession();
    const router = useRouter();
    const { activeForm, setActiveForm } = useAuthContext();
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
    try {
    const res = await fetch("/api/signin", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email,
        password
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      // Server returned an error
      setError(data.error);
      setIsLoading(false);
      return;
    }

    // Success
    setUser(data);
    setIsLoading(false);
    closeForm();
    
    // Redirect to dashboard after successful login
    router.push("/dashboard");
    
    } catch (error) {
    console.error(error);
    setIsLoading(false);
    setError("Unexpected server error");
  }
};

    return (
        <div className="sign-in-container">
            <h3>Sign In</h3>
             <form className="space-y-4" onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="email" className="block text-sm font-medium">
                        Email
                    </label>
                    <input
                        id="email"
                        type="email"
                        name="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter your email"
                    />
                </div>
                <div>
                    <label htmlFor="password" className="block text-sm font-medium">
                        Password
                    </label>
                    <input
                        id="password"
                        type="password"
                        name="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter your password"
                    />
                </div>
                <div className="flex">
                    <button
                    type="submit"
                    className={"w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition cursor-pointer"}
                    >
                        {isLoading ? <span className="text-white inline-flex items-center gap-2">
                                        <span className="animate-pulse">Loading</span>
                                        <LoadingCircles className={"w-6"}/>
                                    </span> :
                        "Sign In"}
                    </button>
                </div>
                {/* Divider */}
                <div className="my-2 flex items-center">
                    <div className="flex-grow border-t border-gray-300"></div>
                    <span className="px-3 text-sm text-gray-500">Or</span>
                    <div className="flex-grow border-t border-gray-300"></div>
                </div>
                    <div className="flex gap-3 cursor-pointer" onClick={()=> setActiveForm("forgotPassword")}>
                        Forgot Password
                    </div>
                {error &&( 
                 <div className="text-red-900">
                    {error}
                 </div>)}
            </form>
        </div>
    );
}